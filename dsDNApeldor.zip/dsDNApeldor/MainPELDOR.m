function Result=MainPELDOR(ExpPar,Conformers)
MagnPar=MagneticParameters('Two Nitroxides');
profiles=Excitation(ExpPar,MagnPar,'Derived from the pulse shape');

%Spherical Coordinates
z=(0:0.01:1)'; theta=acos(z); phi=(0:0.02*pi:2*pi)';  m=(-1:1:1)';

%Grid Variables
[V.THETA,V.PHI,V.M1,V.M2]=ndgrid(theta,phi,m,m);
%Refocused Echo Magnitude
v0=GridRefocusedEcho(profiles,ExpPar.Settings,V,MagnPar);
V0=repmat(trapz(z,trapz(phi,sum(sum(v0,5),4),3),2),[1 size(z,1)]);

Result.LAMBDAS=...
    zeros(size(ExpPar.Settings.k,1),size(z,1),size(Conformers.Distance,1));
for j=1:size(Conformers.Distance,1)
    EA.R1=Conformers.EulerAngles.R1(j,:); 
    EA.R2=Conformers.EulerAngles.R2(j,:);
    lambda=GridPELDOR(profiles,ExpPar.Settings,V,EA,MagnPar);
    Result.LAMBDAS(:,:,j)=trapz(phi,sum(sum(lambda,5),4),3)./V0;
    if round(j/20)==j/20
    plot(z',Result.LAMBDAS(:,:,j)); pause(0.01);
    end
    disp(j); drawnow;
end
pause(0.5);
t=(0:12:2400)'; 
s=TotalSignal(Result.LAMBDAS,z,Conformers.Distance,t)';
plot(t,s);

Result.Conformers=Conformers; Result.MagnPar=MagnPar; Result.ExpPar=ExpPar;
Result.T=t; Result.S=s; Result.z=z;



function s=TotalSignal(lambda,z,r,T)
D=0.326983340102601;                  %Dipolar Interaction Constant
Z=repmat(z',[size(lambda,1) 1 size(lambda,3)]);
R=repmat(reshape(r,[1 1 size(r)]),[size(lambda,1) size(lambda,2) 1]);
s=zeros(size(lambda,1),size(T,1));
for k=1:size(T,1)
    p=1.*mean(lambda.*(cos(D.*T(k).*(3.*Z.^2-1)./R.^3)-1),3);
    s(:,k)=1+trapz(z,p,2);
end