function lambda=GridPELDOR(profiles,SETTINGS,V,EulerAngles,MagnPar)

Y=profiles;


n1=Hedgehog(V.THETA,V.PHI,EulerAngles.R1);
n2=Hedgehog(V.THETA,V.PHI,EulerAngles.R2);

lambda=zeros([size(SETTINGS.B0,1) size(V.THETA)]);

for k=1:size(SETTINGS.B0,1)

    w1=ResonanceFrequency(SETTINGS.B0(k),n1,MagnPar.R1,V.M1);
    w2=ResonanceFrequency(SETTINGS.B0(k),n2,MagnPar.R2,V.M2);

    dwA1=2.*pi.*SETTINGS.DetectionFrequency(k)-w1; 
    dwA2=2.*pi.*SETTINGS.DetectionFrequency(k)-w2;
    dwB2=2.*pi.*SETTINGS.PumpFrequency(k)-w2; 
    dwB1=2.*pi.*SETTINGS.PumpFrequency(k)-w1;
    mx1=interp1(Y.dw,Y.m1x,dwA1); mx2=interp1(Y.dw,Y.m2x,dwA2);
    mz1=interp1(Y.dw,Y.m1z,dwB1); mz2=interp1(Y.dw,Y.m2z,dwB2);

lambda(k,:,:,:,:)=mx1.*mz2 + mx2.*mz1;
   
end