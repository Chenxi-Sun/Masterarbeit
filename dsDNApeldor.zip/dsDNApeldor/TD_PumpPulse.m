function y=TD_PumpPulse(delta,B1max,tp,tau)
%This program calculates the flip probability for a non rectangular pulse
%delta is the frequency offset in [Gigaradian/s]
C=Constants;
ga=C. BohrOverPlanck10m9.*C.ElectronGfactor;
[B1,t,dt]=RiseFallPulse(B1max,tp,tau);
y=zeros(size(delta));

for k=1:length(delta)
        M=[0; 0; 1];
        
            for i=1:length(t)-1
                if B1(i)==0
                    theta=0; 
                else
                    theta=atan(delta(k)./(ga.*B1(i))); 
                end
                phi=sqrt((ga.*B1(i)).^2+delta(k).^2).*dt(i);
                M=Ry(-theta)*Rx(phi)*Ry(theta)*M;
            end
        y(k)=(1-M(3))./2;
end

% plot(delta./(2.*pi),y);