function PELDORplot(Texp,Sexp,T,S)

Nexp = size(Sexp); 
N = size(S);
d= 0.1;
Dexp = repmat(d.*(0:1:Nexp(2)-1),[Nexp(1) 1]);
D = repmat(d.*(0:1:N(2)-1),[N(1) 1]);



plot(Texp,Sexp+Dexp,T,S+D);