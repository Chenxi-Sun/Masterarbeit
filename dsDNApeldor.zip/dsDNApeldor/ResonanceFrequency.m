function y=ResonanceFrequency(B,n,MagnPar,M)
%n consist of (n.x n.y n.z). n is the direction vector. Initially direction
%vector is defined in dipolar frame. n ontains coordinats of this vector in
%radical frame.
g=Teff(MagnPar.g,n);  A=Teff(MagnPar.A,n);
%Classical formula for the electron resonance frequency in the magnetic
%field in the vecinity of nuclei 
C=Constants;
y=C.BohrOverPlanck10m9.*(B.*g + C.ElectronGfactor.*M.*A);

function y=Teff(T,n)
y=sqrt(T(1,1).^2.*n.x.^2 + T(2,2).^2.*n.y.^2 + T(3,3).^2.*n.z.^2);  
