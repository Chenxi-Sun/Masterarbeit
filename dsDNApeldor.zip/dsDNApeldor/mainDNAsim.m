% Optimized double Helix parameters to match PELDOR distances between spin labels

r = 5.85 + 0.65.*randn(100,1);   h= 33;                                    % Helix radius (r) and helix pitch (h) in A
dl0 = 4.76;                                                                % Contour length between base pairs
dh1=1.18; dh2=2.19; phi1=-0.554; phi2=-4.477;                              % Helix start parameters

DNASpinLabel1 = 1; DNASpinLabel2 = 7;                                      % Labeling Positions
n1 = 6 + DNASpinLabel1; n2 = n1 - (DNASpinLabel2 - DNASpinLabel1) ;


[Ix1,Iy1,Iz1,RO1] = SpinLabelFrame(-1,r,h,dl0,n1,phi1,dh1,phi2,dh2);
[Ix2,Iy2,Iz2,RO2] = SpinLabelFrame(1,r,h,dl0,n2,phi1,dh1,phi2,dh2);

[o1,o2,rdd] = DipAxisCoords(RO1,RO2,Ix1,Iy1,Iz1,Ix2,Iy2,Iz2);
[O1,O2,Rdd] = OwnDyn(o1,o2,rdd);                                           % Random dynamics of DNA spin labels

Conformers.EulerAngles.R1 = O1.'; 
Conformers.EulerAngles.R2 = O2.';
Conformers.Distance = Rdd.'./10;

 load('Experimental Parameters.mat', 'Xband');

 Result=MainPELDOR(Xband.SixOffsets,Conformers);
 
 load('Experimental Data.mat', 'Dominik');
 
 [t,S] = PELDORsignals(Dominik.DNA.S0107,Result);
 