function lambda=GridRefocusedEcho(profiles,SETTINGS,V,MagnPar)
Y=profiles;
n1=Hedgehog(V.THETA,V.PHI,[0 0 0]);
n2=Hedgehog(V.THETA,V.PHI,[0 0 0]);
lambda=zeros([size(SETTINGS.B0,1) size(V.THETA)]);
for k=1:size(SETTINGS.B0,1)
    w1=ResonanceFrequency(SETTINGS.B0(k),n1,MagnPar.R1,V.M1);
    w2=ResonanceFrequency(SETTINGS.B0(k),n2,MagnPar.R2,V.M2);

    dwA1=2.*pi.*SETTINGS.DetectionFrequency(k)-w1; 
    dwA2=2.*pi.*SETTINGS.DetectionFrequency(k)-w2;
    
    m1x=interp1(Y.dw,Y.m1x,dwA1); m2x=interp1(Y.dw,Y.m2x,dwA2);

    lambda(k,:,:,:,:)=m1x+m2x;

end