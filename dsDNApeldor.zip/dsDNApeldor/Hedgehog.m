function n=Hedgehog(theta,phi,EulerAngles)
%This program recalculates the unit vectors in a new frame, which is linked
%with the old frame by the Euler angles.
nx=sin(theta).*cos(phi); ny=sin(theta).*sin(phi); nz=cos(theta);

nt=[nx(:)'; ny(:)'; nz(:)'];

ntt=Rz(-EulerAngles(3))*Rx(-EulerAngles(2))*Rz(-EulerAngles(1))*nt;
n.x=reshape(ntt(1,:)',size(theta));
n.y=reshape(ntt(2,:)',size(theta));
n.z=reshape(ntt(3,:)',size(theta));