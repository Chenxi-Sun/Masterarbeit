function [Y]=MagneticParameters(system)


switch system     
    
    case 'One Nitroxide'   
        Y.Sigma = 4.8e-04;
        Y.g = diag([2.0088 2.0065 2.0027]);
        Y.A = diag([0.0005 0.0005 0.00345]);
        
        case 'Trityl'
        Y.Sigma = 0.750e-04;
        Y.g = diag([2.003 2.0027 2.0021]);
        Y.A = diag([0 0 0]);
                
    case 'Two Nitroxides'
        Y.R1.Sigma = 5.5e-04;
        Y.R1.g = diag([2.0088 2.0066 2.0027]);
        Y.R1.A = diag([0.0005 0.0005 0.00345]);
        Y.R2.Sigma = 5.5e-04;
        Y.R2.g = diag([2.0088 2.0066 2.0027]);
        Y.R2.A = diag([0.0005 0.0005 0.00345]);
        
        
    case 'Nitroxide+Tityl'
        Y.R1.Sigma = 1.750e-04;
        Y.R1.g = diag([2.0088 2.0066 2.0027]);
        Y.R1.A = diag([0.0005 0.0005 0.0035]);
        Y.R2.Sigma = 0.750e-04;
        Y.R2.g = diag([2.003 2.0027 2.0021]);
        Y.R2.A = diag([0 0 0]);
end