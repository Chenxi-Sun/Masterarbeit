function [O1,O2,R]=OwnDyn(o1,o2,r)
m=11;
N=length(r);
da = 0.1; db = 0.1; dg = 0.1; 
dr=sqrt(2);

for i1=1:N
    O1(1,(i1-1)*m+1:i1*m)=o1(1,i1)+0.*randn(1,m);
    O1(2,(i1-1)*m+1:i1*m)=o1(2,i1)+db.*randn(1,m);
    O1(3,(i1-1)*m+1:i1*m)=o1(3,i1)+dg.*randn(1,m);
    
    O2(1,(i1-1)*m+1:i1*m)=o2(1,i1)+da.*randn(1,m);
    O2(2,(i1-1)*m+1:i1*m)=o2(2,i1)+db.*randn(1,m);
    O2(3,(i1-1)*m+1:i1*m)=o2(3,i1)+dg.*randn(1,m);
    
    R(1,(i1-1)*m+1:i1*m)=r(i1)+dr.*randn(1,m);
end
