function [o1,o2,Rdd] = DipAxisCoords(RO1,RO2,x1,y1,z1,x2,y2,z2)

Rd = RO1 - RO2;
N= size(Rd); o1 = zeros(N); o2 = zeros(N); Rdd = sqrt(sum(Rd.^2,1));

for n=1:N(2)
    x = x2(:,n); y = y2(:,n); z = z2(:,n); rd = Rd(:,n);
    
    Zd =rd./norm(rd);
    crossRdZ = cross(rd,z); NormCrossRdZ = norm(crossRdZ);
    if NormCrossRdZ == 0 
        Xd = x; Yd = y; 
    else
        Xd = crossRdZ./NormCrossRdZ; Yd = cross(Zd,Xd);
    end
    
    
    Nold.x = Xd; Nold.y = Yd; Nold.z = Zd;
    Nnew.x = x;  Nnew.y = y;  Nnew.z = z; 
    [a,b,c]=EulerAngles(Nold,Nnew);
    o1(:,n) = [a; b; c];
    
    Nnew1.x = x1(:,n);  Nnew1.y = y1(:,n);  Nnew1.z = z1(:,n); 
    [a,b,c]=EulerAngles(Nold,Nnew1);
    o2(:,n) = [a; b; c];
end