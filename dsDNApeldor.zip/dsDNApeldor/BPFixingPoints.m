function s=BPFixingPoints(r,h,dl0,bp,phi,dh)
% This program computes coordinate of the points where base pair are fixed
% to DNA strands
% bp is the number of base pair (in our case from +10 to -10)
% Optimal Parameters
% r=5.85 h=33 dl0=4.85 (this distance between two base pairs along helix)
% bp is the number of the base pair
% phi describes the start of the helix with bp=0, phi=-0.57
% dh also describes the start of the helix with bp=0, dh=1.18;

[R,H,DL0]=ndgrid(r,h,dl0);

A=HelixParameter(H,R,DL0);

fi=2.*pi.*A.*bp+phi; 
X=R.*cos(fi);       
Y=R.*sin(fi);       
Z=H.*A.*bp + dh;    

s(1,:)=X(:);  s(2,:)=Y(:);  s(3,:)=Z(:);


function y=HelixParameter(H,R,DL0)
y=DL0./sqrt(H.^2+(2.*pi.*R).^2);