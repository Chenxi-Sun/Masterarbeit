function Y=Excitation(ExpPar,MagnPar,ExcitationProfile)
C=Constants;
A=C.BohrOverPlanck10m9.*C.ElectronGfactor;

FA1=ExpPar.Sequence.FirstPulse.FlipAngle;  PL1=ExpPar.Sequence.FirstPulse.Length;
FA2=ExpPar.Sequence.SecondPulse.FlipAngle; PL2=ExpPar.Sequence.SecondPulse.Length;
FA3=ExpPar.Sequence.ThirdPulse.FlipAngle;  PL3=ExpPar.Sequence.ThirdPulse.Length;
FAP=ExpPar.Sequence.PumpPulse.FlipAngle;  
PLP=ExpPar.Sequence.PumpPulse.Length;
RFT=ExpPar.Sequence.PumpPulse.tau;

s1=MagnPar.R1.Sigma; s2=MagnPar.R2.Sigma;
ddb1=s1/20; db1=(-4*s1:ddb1:4*s1)'; ddb2=s2/20; db2=(-4*s2:ddb2:4*s2)'; 
%Maximal difference between resonance and detection frequencies. The
%program scan resonance frequencies depending nitroxide orientations
nuB=mean(ExpPar.Settings.PumpFrequency);
DeltaW1=SpecWidth(nuB,MagnPar.R1,'cyclic frequency'); 
DeltaW2=SpecWidth(nuB,MagnPar.R2,'cyclic frequency'); 
DeltaW=max([DeltaW1 DeltaW2]);
x=(-1:0.025:1)'; dw=DeltaW.*sign(x).*x.^2; Y.dw=dw;
%Grid Variables
[DW1,DB1]=ndgrid(dw,db1);

mm1x=Mx(FA1,PL1,FA2,PL2,FA3,PL3,DW1+A.*DB1).*GaussCurve(DB1,0,s1);
Y.m1x=trapz(db1,mm1x,2); 
mm1z=Mz(FAP,PLP,RFT,dw,4.*A.*s1,DW1+A.*DB1,ExcitationProfile).*GaussCurve(DB1,0,s1);
Y.m1z=trapz(db1,mm1z,2); 
%%%%%
[DW2,DB2]=ndgrid(dw,db2);
mm2x=Mx(FA1,PL1,FA2,PL2,FA3,PL3,DW2+A.*DB2).*GaussCurve(DB2,0,s2);
Y.m2x=trapz(db2,mm2x,2); 
mm2z=Mz(FAP,PLP,RFT,dw,4.*A.*s2,DW2+A.*DB2,ExcitationProfile).*GaussCurve(DB2,0,s2);
Y.m2z=trapz(db2,mm2z,2); 
%%plot(dw,Y.m1z,dw,Y.m2z);



function y=Mz(FlipAngle,PulseLength,RiseFallTime,dw0,ddw,DW,ExcitationProfile)
dw=[dw0(1)-ddw; dw0; dw0(end)+ddw];
switch ExcitationProfile
    case 'Derived from the pulse shape'
        B1max=Bone(FlipAngle,PulseLength);
        mz=TD_PumpPulse(dw,B1max,PulseLength,RiseFallTime);
    case 'Gauss'
        mzg=GaussCurve(dw,0,0.5.*FlipAngle./PulseLength);
        mz=mzg./max(mzg);
    case 'Lorentz'
        mzl=LorentzCurve(dw,0,0.5.*FlipAngle./PulseLength);
        mz=mzl./max(mzl);
end
y=interp1(dw,mz,DW);