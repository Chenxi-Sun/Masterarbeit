function [Ix,Iy,Iz,RO]=SpinLabelFrame(P,r,h,dl0,bp,phi1,dh1,phi2,dh2)
% This program computes RO - the coordinates of the unpaired electron 
% of the C (Snorri) spin label and Ix, Iy, Iz - the nitroxide axis vectors
z = [0; 0; 1];
a = 12.3;
THETA = 0.3742;
r1=BPFixingPoints(r,h,dl0,bp,phi1,dh1);    % Coordinates of the first Carbon atom to which base pair is attached
r2=BPFixingPoints(r,h,dl0,bp,phi2,dh2);    % Coordinates of the second Carbon atom to which base pair is attached
Dr=r2-r1; 
FixingPoint = (r1+P.*r1+r2-P.*r2)./2; % P indicates strand to which spin label is attached, P = -1 for the first spin label

K=size(Dr); RO =zeros(K);  Ix = zeros(K); Iy = zeros(K); Iz = zeros(K);

for k=1:K(2)
    dr=Dr(:,k);         dr = dr./norm(dr);
    u = cross(z,dr);    u = u./norm(u);
    bpZ = cross(dr,u);  bpZ = bpZ./norm(bpZ);
    Iz(:,k)= bpZ;
    NOx = RotateVectorAroundAxis(u,-P.*(3/4).*THETA.*bpZ);
    Ix(:,k) = NOx;
    NOy = RotateVectorAroundAxis(NOx,(pi/2).*bpZ);
    Iy(:,k) = NOy;
    label = RotateVectorAroundAxis(u,-P.*THETA.*bpZ);
    RO(:,k) = FixingPoint(:,k) + a.*label;
end