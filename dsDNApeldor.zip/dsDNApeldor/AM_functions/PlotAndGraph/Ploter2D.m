function Ploter2D(x,y,Z)

M=length(x); N=length(y);
if M*N==1
    plot3(x,y,Z);
elseif M==1
    plot(y,Z);
elseif N==1
    plot(x,Z);
else
    [X,Y]=ndgrid(x(:),y(:));
    surf(X,Y,Z);
end
