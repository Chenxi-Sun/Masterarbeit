function y=Bone(FlipAngle,PulseLength)
% PulseLength is in [ns]
% FlipAngle is in [radian]

C=Constants;

y=FlipAngle./(C.BohrOverPlanck10m9.*C.ElectronGfactor.*PulseLength);

% y is in [T]