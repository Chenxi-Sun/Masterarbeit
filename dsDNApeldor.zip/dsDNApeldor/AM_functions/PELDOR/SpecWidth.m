function [dy,y]=SpecWidth(nuB,MagnPar,option)
%If the option 'field' is chosen, then this function determines 
%the cental resonance field for the spectrum recorded at microwave frequency nuB
%It also determines the width of the spectrum in [Tesla]
C=Constants;
B0=2.*pi.*nuB./(C.BohrOverPlanck10m9.*C.ElectronGfactor);

b(:,1)=C.ElectronGfactor.*(B0-diag(MagnPar.A))./diag(MagnPar.g);
b(:,2)=C.ElectronGfactor.*(B0+diag(MagnPar.A))./diag(MagnPar.g);
b0=min(min(b))-5.*MagnPar.Sigma; b00=max(max(b))+5.*MagnPar.Sigma;
%b0 gives us the left limit for the spectrum obtained with the mw-frequency nuB
%b00 gives us the right limit for the spectrum obtained with the mw-frequency nuB

dB=b00-b0;
Bcentr=(b00+b0)./2;



switch option
    case 'field'
        dy=dB;                                                      %The result is [Tesla]
        y=Bcentr;
    case 'frequency'
        dy=dB.*C.BohrOverPlanck10m9.*C.ElectronGfactor./(2.*pi);    %The result is in [GHz]
        y=nuB;
    case 'cyclic frequency'
        dy=dB.*C.BohrOverPlanck10m9.*C.ElectronGfactor;  
        y=2.*pi.*nuB;                                               %The result is in [GIGAradian/second]
end