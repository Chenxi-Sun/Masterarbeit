function [B1,t,dt]=RiseFallPulse(B1max,tp,tau)
%This program calculates the shape of the B1 field in non rectangular pulse
%time consists of two periods: in the first the field rises and in the
%second tthe fields decays exponentially
N=100;
if tau == 0
    B1=[B1max B1max]; 
    t=[0 tp]; 
    dt=tp;
else
    
    y=exp(-tp./tau);
    t_begin=-tau.*log(linspace(1,y,N));    t_end=-tau.*log(linspace(1,0.001,N));

    B1_begin=1-exp(-t_begin./tau);  B1_end=B1_begin(end).*exp(-t_end./tau);

    t=[t_begin t_begin(end)+t_end(2:end)];
    B1=B1max.*[B1_begin B1_end(2:end)];

    dt=diff(t);
end

%plot(t,B1);