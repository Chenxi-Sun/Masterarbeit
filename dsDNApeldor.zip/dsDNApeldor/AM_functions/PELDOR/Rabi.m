function y=Rabi(B1,dw)
%B1 is in [T]
%dw is in GIGAradian/s
C=Constants;
g=C.BohrOverPlanck10m9.*C.ElectronGfactor;
y=sqrt(g.^2.*B1.^2+dw.^2);
%y is in GIGAradian/s