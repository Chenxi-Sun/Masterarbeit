function y=Mx(FlipAngle1,PulseLength1,FlipAngle2,PulseLength2,FlipAngle3,PulseLength3,dw)
% Mx is the x-component magnetization of the refocused echo 
% FlipAngles and Pulselengthes are the parameter of the three pulses
% dw is the cyclic frequency offset in [GIGAradian/s]
C=Constants; 
A=C.BohrOverPlanck10m9.*C.ElectronGfactor;
B1_1=Bone(FlipAngle1,PulseLength1); W1=Rabi(B1_1,dw);
B1_2=Bone(FlipAngle2,PulseLength2); W2=Rabi(B1_2,dw);
B1_3=Bone(FlipAngle3,PulseLength3); W3=Rabi(B1_3,dw);

y=(A.*B1_1./W1).*sin(W1.*PulseLength1).*...
(A.*B1_2./W2).^2.*(1-cos(W2.*PulseLength2))./2.*...
(A.*B1_3./W3).^2.*(1-cos(W3.*PulseLength3))./2;