function [C,CC,spins,C0,CC0] = Couplings(system)
% The numbers el_N indicate which of the spins are electrons

const=Constants;  
EGM = const.ElectronGyroMagn; EGF =const.ElectronGfactor; cE = (EGM./EGF).*10^(-9);
NGM = const.NitrogenGyroMagn;  cN = NGM.*10^(-9);   
PGM = const.ProtonGyroMagn;    cP = PGM.*10^(-9);
MHz2GIGAradPerS = 2.*pi./1000;


switch system                

    case 'Nitroxide'

        spins.values   = [0.5 1]; 
        spins.carrier  = ['e'; 'N']; 
        spins.GyroMagn = [EGM; NGM];
        N = length(spins.values); 
       
        C=zeros(3,3,N);  CC=zeros(3,3,N,N);
        %C1(:,:,1) = cE.*diag([2.0088 2.0066 2.0027]);
        C(:,:,1) = cE.*diag([2.0088 2.006 2.002]);                         %g-Tensor: Sezer, D., et al. (2009).  PCCP, 11, 6638. 
        C(:,:,2) = cN.*diag([1 1 1]);                 
       
        %Ahf   = diag( [ 15   15     90 ] );                               %Hyperfine Tensor in MHz
        Ahf   = diag( [ 17.65572   17.65572     105.0936 ] );              %Hyperfine Tensor in MHz: Sezer, D., et al. (2009).  PCCP, 11, 6638 
        %Ahf   = diag( [ 15   15     102 ] );                              %HF for Tonda acetone
        %Ahf   = diag( [ 17.9   17.9     107.2 ] );                        %HF for Tonda Water
        %Ahf   = diag( [ 16.4   16.4     98.4 ] );                          %HF for Petr paper TEMPOL in toluene spectrum
        
        Quadr = diag( [ 0.1  1.6  -1.7 ] );                                %Quadrupolar coupling in MHz rougly corresponds to literature
        
        CC(:,:,1,2) = Ahf  .*MHz2GIGAradPerS;
        CC(:,:,2,2) = Quadr.*MHz2GIGAradPerS;  
        
        
   

end

[C0,CC0]=AveragedTensors(C,CC);



function [C0,CC0]=AveragedTensors(C,CC)

NumberOfSpins = size(C,3);

C0 = zeros(size(C)); CC0 = zeros(size(CC));

    for i1= 1:NumberOfSpins
        C0(:,:,i1) = TracedTensor(C(:,:,i1));
        for j1=i1:NumberOfSpins
            CC0(:,:,i1,j1)= TracedTensor(CC(:,:,i1,j1));
        end        
    end