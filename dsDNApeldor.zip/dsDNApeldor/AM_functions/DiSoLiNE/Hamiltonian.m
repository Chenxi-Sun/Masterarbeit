function H=Hamiltonian(B0,MuOhbar,AA,spins)
% Detection of number of paticle in the system 
 N=length(spins.values);
% Generation of required spin operators
 S=ManySpins(spins.values);
% In S(:,:,l,i) l gives projection direction and i gives the number of particle.


if size(B0)==1
    B=zeros(3,N);
    B(3,:)=B0;
else
    B=B0;
end
% Zeeman part of the Hamiltonian
HZ=0;
for i1=1:N
    for k1=1:3
        for l1=1:3
            HZ=HZ - B(k1,i1).*MuOhbar(k1,l1,i1).*S(:,:,l1,i1);
        end
    end
end
% Coupling between spin i and spin j. Generally i can be equal to j.
H_ij=0;  
for i1=1:N
    for j1=i1:N
        for k1=1:3
            for l1=1:3
               S1=S(:,:,k1,i1); S2=S(:,:,l1,j1);
               H_ij=H_ij+AA(k1,l1,i1,j1).*S1*S2;
            end
        end
    end
end
% Total Hamiltonian
H=HZ+H_ij;   