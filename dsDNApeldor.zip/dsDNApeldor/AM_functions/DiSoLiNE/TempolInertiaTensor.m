function [InertiaTensor, PrincComponents, InertiaMoment,eta] = TempolInertiaTensor(Temperature)
C = Constants;
load('TempolXYZ.mat','mass','XYZ');
% mass is in proton mass units
% XYZ in Angstrom
N = length(mass);

mass = C.ProtonMass.*mass;
XYZ = XYZ.*10^(-10);
MR=0;
for k = 1:N
    MR = MR + mass(k).*XYZ(k,:);
end
R = MR./sum(mass);

InertiaTensor = zeros(3,3);
for k = 1:N
    r = XYZ(k,:) - R;
    
    for k1 = 1:3
        for k2 =1:3
    InertiaTensor(k1,k2) = InertiaTensor(k1,k2) + mass(k).*r(k1).*r(k2);
        end
    end
end

PrincComponents = eig(InertiaTensor); InertiaMoment = trace(InertiaTensor)./3;

kBT = C.Boltzmann.*Temperature;
eta = sqrt(kBT./InertiaMoment);