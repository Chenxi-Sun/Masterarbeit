function [Sx,Sy,Sz,Sp,Sm] = GetOps(spins,ParticleNumbers)
% This function extract some specified operators from a larger array
S=ManySpins(spins); 

Sx = sum(S(:,:,1,ParticleNumbers),4);  
Sy = sum(S(:,:,2,ParticleNumbers),4); 
Sz = sum(S(:,:,3,ParticleNumbers),4);

Sp = Sx + 1i.*Sy;    
Sm = Sx - 1i.*Sy;    