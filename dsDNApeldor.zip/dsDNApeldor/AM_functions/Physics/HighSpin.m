function S=HighSpin(s)
% This function generates 3 spin projection operator matrices for a given
% spin s, which is a positive half integer value.
% The output S is a (2s+1)x(2s+1)x3 matrix.
% The formulas for the computations are taken from 
% (Pool C. P., Farach H. A., 'Theory of magnetic resonance')
M=2.*s+1; 
Ax=zeros(M,M); Ay=zeros(M,M);  Az=zeros(M,M);
    for m1=1:M
        m=s-m1+1;
        for n1=1:M
            n=s-n1+1;
            a=sqrt(s.*(s+1)-m.*n);
            Ax(m1,n1)=(1./2).*(KroneckerDelta(m,n+1)+KroneckerDelta(m+1,n)).*a;
            Ay(m1,n1)=(1./(2.*1i)).*(KroneckerDelta(m,n+1)-KroneckerDelta(m+1,n)).*a;
            Az(m1,n1)=m.*KroneckerDelta(m,n);
        end
    end
    
S(:,:,1)=Ax;  S(:,:,2)=Ay;  S(:,:,3)=Az;
    
