function tc= EinsteinStoke(T,rA,eta)
% T is temperature
% eta is viscosity, for water at 300 K, eta = 0.00085 N*s/m^2
% rA is the molecular radius in A, for TEMPOL the radius rA is about 3 A
C = Constants;
a = 4.*pi./(3.*C.Boltzmann);

r = rA.*10.^(-10);  % Angstrom to meter
tc = 10.^12.*a.*eta.*r.^3./T; % in ps