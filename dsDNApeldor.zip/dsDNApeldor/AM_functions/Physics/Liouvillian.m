function y=Liouvillian(H)
y=kron(H,eye(size(H)))-kron(eye(size(H)),H.');