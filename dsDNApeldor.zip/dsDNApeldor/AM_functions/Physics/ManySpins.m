function S=ManySpins(spins)
% This function generates the spin operators of a system of many spins
% Variable 'spins' coontain the value of spin for each particle of the system
% S(k1,k2,m,n) is 4-dimensional matrix. m gives the spinprojection (x,y,z),
% n corresponds to the number of spin particle
N=length(spins); M=2.*spins+1;

if N==1
    %One spin case
    S=HighSpin(spins);
elseif N==2
    %Two spins case
    s1=HighSpin(spins(1));
    S(:,:,1,1)=kron(s1(:,:,1),eye(M(2)));
    S(:,:,2,1)=kron(s1(:,:,2),eye(M(2)));
    S(:,:,3,1)=kron(s1(:,:,3),eye(M(2)));
    s2=HighSpin(spins(2));
    S(:,:,1,2)=kron(eye(M(1)),s2(:,:,1));
    S(:,:,2,2)=kron(eye(M(1)),s2(:,:,2));
    S(:,:,3,2)=kron(eye(M(1)),s2(:,:,3));
else
    %More than two spin case
    m=prod(M);
    S=zeros(m,m,3,N);
    
    m1=prod(M(2:end));
    s1=HighSpin(spins(1));
    S(:,:,1,1)=kron(s1(:,:,1),eye(m1));
    S(:,:,2,1)=kron(s1(:,:,2),eye(m1));
    S(:,:,3,1)=kron(s1(:,:,3),eye(m1));
    for i1=2:N-1
        s=HighSpin(spins(i1));
        m0=prod(M(1:i1-1)); m00=prod(M(i1+1:N));
        S(:,:,1,i1)=kron(eye(m0),kron(s(:,:,1),eye(m00)));
        S(:,:,2,i1)=kron(eye(m0),kron(s(:,:,2),eye(m00)));
        S(:,:,3,i1)=kron(eye(m0),kron(s(:,:,3),eye(m00)));
    end
    
    mend=prod(M(1:end-1));
    send=HighSpin(spins(end));
    S(:,:,1,end)=kron(eye(mend),send(:,:,1));
    S(:,:,2,end)=kron(eye(mend),send(:,:,2));
    S(:,:,3,end)=kron(eye(mend),send(:,:,3));
end

