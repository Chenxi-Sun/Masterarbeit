function const=Constants

const.Planck                  =1.054571628000000e-34; % [J*s]
const.h                       =2.*pi.*const.Planck;   % [J*s]
const.c                       =3e+8;                  % [m/s] light velocity
const.magnetic                =1.256637061435917e-06; % mkg/(A^2s^2) 
const.electric                =8.85418782e-12;        % [A^2s^4/(kgm^3)] 
const.Boltzmann               =1.380650400000000e-23; % [J/K]
const.Avogadro                =6.022141.*10^23;
const.ElectronMass            =9.10938291e-31;        % [kg]
const.ProtonMass              =1.672621777e-27;       % [kg]
const.ElementarCharge         =1.6021766208e-19;      % [A*s]=[q]

const.Rydberg                 = 1.09737315685e7.*const.c;  % [1/m]
const.BohrRadius              = 0.52917721092e-10;     % [m]
const.BohrMagneton            = 9.274009150000001e-24; % [J/T]
const.NuclearMagneton         = 5.050783000000000e-27; % [J/T]
const.BohrOverPlanck10m9      = 87.941007550034370;    % GIGAradian/(T*s)
const.NuclMagnOverPlanck10m9  = 0.047894167317765;     % GIGAradian/(T*s)
const.Ddip                    = 0.3269833401026;       % [GIGAradian*nm^3]  \mu_0/(4\pi)\gamma_e^2\hbar
const.DdipPP                  = 7.547372e-7;           % [GIGAradian*nm^3]  \mu_0/(4\pi)\gamma_p^2\hbar
const.DdipEP                  = -4.967761e-4;          % [GIGAradian*nm^3]  \mu_0/(4\pi)\gamma_p\gamma_e\hbar

const.ElectronGyroMagn        = -1.760859770306435e+11; % radian/(T*s)
const.ProtonGyroMagn          =  2.675222099000000e+08; % radian/(T*s)
const.CarbonGyroMagn13C       =  6.72828e+7;
const.NitrogenGyroMagn        =  1.9338e+7;             % radian/(T*s)
const.NitrogenGyroMagn15N     = -2.7116e+7;             % radian/(T*s)

const.ProtonGfactor           = 5.585694713000000;
const.ElectronGfactor         = 2.002319304000000;