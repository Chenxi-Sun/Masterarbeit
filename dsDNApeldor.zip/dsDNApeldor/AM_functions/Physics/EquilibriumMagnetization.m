function M0=EquilibriumMagnetization(B0,C1,C2,spins,n,Temperature)
% n specifies numbers of particles, which contribute to the magnetization

C=Constants;

H=C.Planck.*10^9.*LFHamiltonian(B0,C1,C2,spins);
rho0=EquilibriumDensityMatrix(H,Temperature,'Exact');

S=ManySpins(spins.values); Sz=sum(S(:,:,3,n),4);
M0=trace(Sz*rho0);
