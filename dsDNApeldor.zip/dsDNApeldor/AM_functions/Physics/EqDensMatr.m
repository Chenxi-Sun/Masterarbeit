function rho=EqDensMatr(H,T,form)
% form can be either 'Reduced Form' or 'Full Form';

C=Constants;   h=H./(C.Boltzmann.*T);

switch form
    case 'Reduced Form'
    % This form is applicable in high temperature limit
        A=trace(expm(-h));
        rho=-h./A;
        
    case 'Full Form'
        [V,D]=eig(h);  
        maxD=max(max(abs(D)));
        if maxD<500
            A=trace(expm(-h));
            rho=expm(-h)./A;
        else
            d=diag(D);
            m=find(d==min(d));
            diagRho=zeros(length(d),1);  
            diagRho(m)=1./length(m);  
            DiagRho=diag(diagRho);
            rho=V*DiagRho/(V);
        end
end