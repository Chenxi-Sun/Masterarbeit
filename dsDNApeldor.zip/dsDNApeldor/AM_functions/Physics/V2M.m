function M=V2M(v)
%This function is the inverse function to v=M2V(M) function.
%The vector v is cuted in n smaller column vectors. These columns are
%inserted in the matrix M as the rows.
n=sqrt(length(v)); m=reshape(v,[n n]);
M=m.';