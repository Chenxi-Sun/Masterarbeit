function v=M2V(M)
% This function is the inverse function to M=V2M(v) function.
% The vector v is constructed out of M rows
m=M.'; v=m(:);
