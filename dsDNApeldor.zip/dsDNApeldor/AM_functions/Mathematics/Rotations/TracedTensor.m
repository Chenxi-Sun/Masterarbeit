function TT = TracedTensor(T)

I=eye(size(T));  TT=I.*trace(T)./trace(I);