function EA=StandardEulerAngleGridReduced(M)
d=1/M;
z=(0+d/2:d:1-d/2).';  beta = acos(-z);
x=(0+d/2:d:0.5-d/2).'; gamma = pi*x;  
[ Beta, Gamma] = ndgrid( beta, gamma);

EA = [0.*Beta(:) Beta(:) Gamma(:)];