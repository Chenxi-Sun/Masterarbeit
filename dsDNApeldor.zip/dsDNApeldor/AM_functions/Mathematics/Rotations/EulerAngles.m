function [a,b,c]=EulerAngles(Nold,Nnew)
% This program calculate the Euler angles, when the unit vectors of the new and the old frames are known.

% Nold variable is a stuct variable which contains 3 fields: Nold.x, Nold.y, Nold.z
% Nold.x is [3x1] vector, Nold.y, Nold.z are also [3x1] vectors.
% Nnew is a similar structure variable.
% [-pi<a<pi],[0<b<pi],[-pi<c<pi]

NNold=[Nold.x Nold.y Nold.z];
NNnew=[Nnew.x Nnew.y Nnew.z];
Nab=zeros(3,3);
for i1=1:3
    for j1=1:3
        Nab(i1,j1)=dot(NNold(:,i1),NNnew(:,j1));
    end
end




if abs(Nab(3,3))==1
    a=angle(Nab(1,1)+1i.*Nab(2,1)); b=acos(Nab(3,3)); c=0;
else
    L=cross(Nold.z,Nnew.z);
    LL=sqrt(sum(L.^2,1));
    l=L./LL;
    yy=cross(Nnew.z,l);
    
    lx=dot(Nold.x,l); ly=dot(Nold.y,l);
    a=angle(lx+1i.*ly);
    b=acos(Nab(3,3));
    ax=dot(l,Nnew.x); ay=dot(yy,Nnew.x);
    c=angle(ax+1i.*ay);
end
