function [theta, phi]=BallCover(N)
% This function creates homogeneously distributed points on a sphere
% N is the number of points
t=((-N+1:1:N)'-1/2)./N; 

theta=acos(t); 
phi=sqrt(pi.*N).*asin(t);

%plot3(sin(theta).*cos(phi), sin(theta).*sin(phi), cos(theta),'*');