function y=Rz(a)
%Three dimensional rotation matrix arround z-xis
y=eye(3);
y(1,1)=cos(a);  y(1,2)=-sin(a);
y(2,1)=sin(a);  y(2,2)=cos(a);