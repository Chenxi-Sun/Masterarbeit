function TT=TensorTransformationInverse(alpha,beta,gamma,T)
%Tensor value T is known in the old frame. A new frame is obtained by
%three Euler rotations (alpha,beta,gamma).
%Tensor value TT in the new frame is expressed via the value T
R=Rz(alpha)*Rx(beta)*Rz(gamma);
TT=R.'*T*R;