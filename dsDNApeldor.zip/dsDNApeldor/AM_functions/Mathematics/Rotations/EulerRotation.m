function Nfin = EulerRotation(Ninit,a,b,c)

Na.x = RotateVectorAroundAxis(Ninit.x, a.*Ninit.z);
Na.y = RotateVectorAroundAxis(Ninit.y, a.*Ninit.z);
Na.z = RotateVectorAroundAxis(Ninit.z, a.*Ninit.z);


Nb.x = RotateVectorAroundAxis(Na.x, b.*Na.x);
Nb.y = RotateVectorAroundAxis(Na.y, b.*Na.x);
Nb.z = RotateVectorAroundAxis(Na.z, b.*Na.x);

Nc.x = RotateVectorAroundAxis(Nb.x, c.*Nb.z);
Nc.y = RotateVectorAroundAxis(Nb.y, c.*Nb.z);
Nc.z = RotateVectorAroundAxis(Nb.z, c.*Nb.z);

Nfin=Nc;