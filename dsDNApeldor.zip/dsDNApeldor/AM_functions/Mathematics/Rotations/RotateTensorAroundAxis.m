function TENSOR = RotateTensorAroundAxis(tensor,axis)
%This program rotate "tensor" around "axis". 
%Parameter "axis" is a three dimensional vector (column)
%The magnitude of the parameter "axis" corresponds to the rotation angle

PHI=norm(axis);
if PHI==0
    TENSOR=tensor;
else
NormAxis=axis./PHI;
alpha=angle(axis(1)+1i.*axis(2));
beta=acos(NormAxis(3));
%T1 is the tensor value in the frame (x�,y�,z�)
%It is obtained by the rotation of (xyz) plane by angle alpha+p/2 around z
%and later by rotation beta around the current x-axis
T1=TensorTransformationInverse(alpha+pi/2,beta,0,tensor);
%Trot is the rotated tensor in the new frame
Trot=Rz(PHI)*T1*Rz(-PHI);
%TENSOR is the rotated tensor in the old frame
TENSOR=TensorTransformation(alpha+pi/2,beta,0,Trot);
end