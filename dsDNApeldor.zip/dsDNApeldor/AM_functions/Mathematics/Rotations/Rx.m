function y=Rx(a)
%Three dimensional rotation matrix arround x-xis
y=eye(3);
y(2,2)=cos(a);  y(2,3)=-sin(a);
y(3,2)=sin(a);  y(3,3)=cos(a);