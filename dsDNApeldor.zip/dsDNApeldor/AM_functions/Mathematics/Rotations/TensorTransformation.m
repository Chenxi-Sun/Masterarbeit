function T=TensorTransformation(alpha,beta,gamma,TT)
% Tensor value TT is known in the new frame wich is obtained by
% three ZXZ-Euler rotations (alpha,beta,gamma) of the old frame.
% Tensor value T in the old frame is expressed via the value TT
R=Rz(alpha)*Rx(beta)*Rz(gamma);
T=R*TT*R.';