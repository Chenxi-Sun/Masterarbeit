function VECTOR = RotateVectorAroundAxis(vector,axis)
%This program rotate "vector" around "axis". 
%Parameter "axis" is a three dimensional vector (column)
%The magnitude of the parameter "axis" corresponds to the rotation angle
%Parameter vector is a matrix of a size 3xN, where N=1,2,3, ...
%Example: VECTOR = Rotation([1;0;0],pi/2*[0;0;1]); Result VECTOR=[0;1;0];
PHI=norm(axis);
if PHI==0
    VECTOR=vector;
else
NormAxis=axis./PHI;

alpha=angle(axis(1)+1i.*axis(2));
beta=acos(NormAxis(3));
VECTOR=Rz(alpha-pi/2)*Rx(-beta)*Rz(PHI)*Rx(beta)*Rz(pi/2-alpha)*vector;
end