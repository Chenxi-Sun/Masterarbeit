function y=Ry(a)
%Three dimensional rotation matrix arround y-xis
y=eye(3);
y(1,1)=cos(a);  y(1,3)=sin(a);
y(3,1)=-sin(a);  y(3,3)=cos(a);