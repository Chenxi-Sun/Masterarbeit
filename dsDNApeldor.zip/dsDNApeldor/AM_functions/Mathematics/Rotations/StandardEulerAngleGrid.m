function EA=StandardEulerAngleGrid(M)
d=1/M;
z=(-1+d/2:d:1-d/2).'; beta = acos(-z);
alpha = pi.*z; 
gamma = pi*z;  
[Alpha, Beta, Gamma] = ndgrid(alpha, beta, gamma);

EA = [Alpha(:) Beta(:) Gamma(:)];