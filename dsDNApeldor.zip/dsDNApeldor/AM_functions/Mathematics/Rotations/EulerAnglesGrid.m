function [Alpha,Beta,Gamma,M,MM] = EulerAnglesGrid(N,CoverType,p)
% Normal 
NN=10;
z=linspace(0,1,NN+1).';
a = z.*p.*pi; a(end)=[];
b = acos(z);
g = z.*p.*pi; g(end)=[];
% Optimized
 zo=zeros(2^N+1,1);  zo(2)=1; 
 m=3; n=1; k=1;
        while n<=N
            while 2*k-1 < 2^n
            zo(m)=(2*k-1)/2^n;
            k=k+1;
            m=m+1;
            end
        n=n+1;
        k=1;
        end
        
n=(1:1:N).';
ao = zo.*p.*pi;  ao(2)=[];  n1=[0;2.^n];
bo = acos(1-zo);            n2=[0;2.^n+1];  
go = zo.*p.*pi; go(2)=[];   n3=[0;2.^n];
               
        
switch CoverType
    case 'Normally Sorted'      
        [A,B,G]=ndgrid(a,b,g); 
        Alpha=A(:);Beta=B(:); Gamma=G(:);
        M=NN*(NN+1)*NN; MM=M;
        
    case 'Optimized Sorted'
        [G,Bo]=ndgrid(g,bo); 
        Beta=Bo(:); Gamma=G(:); Alpha=0.*Beta;
        M=(2^N+1)*NN;
        MM=(2.^n+1).*NN;
        
    case 'Optimized Sorted Full'
        alpha=0; 
            M=(2^N+1)*2^N;    MM=(2.^n+1).*2.^n;
            Alpha=zeros(M,1); Beta=zeros(M,1); Gamma=zeros(M,1);
            K=0;
            for k0=2:N+1
                for k2=1:n2(k0)
                    for k3=1:n3(k0)
                        if  k2>n2(k0-1) || k3>n3(k0-1)
                            K=K+1;
                            Alpha(K)=alpha;
                            Beta(K)=bo(k2);
                            Gamma(K)=go(k3);
                        end
                    end
                end
            end
            
    case 'Optimized Sorted 3 Angles'
        
        M=2^N*(2^N+1)*2^N;   MM=2.^n.*(2.^n+1).*2.^n;
            Alpha=zeros(M,1); Beta=zeros(M,1); Gamma=zeros(M,1);
            K=0;
            for k0=2:N+1
                for k1=1:n1(k0)
                    for k2=1:n2(k0)
                        for k3=1:n3(k0)
                            if k1>n1(k0-1) || k2>n2(k0-1) || k3>n3(k0-1)
                            K=K+1;
                            Alpha(K) = ao(k1);
                            Beta(K)  = bo(k2);
                            Gamma(K) = go(k3);
                            end
                        end
                    end
                end
            end
end