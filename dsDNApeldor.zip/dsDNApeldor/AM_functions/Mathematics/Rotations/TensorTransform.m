function T=TensorTransform(Nold,Nnew,TT)

% Tensor value TT is known in the new frame

R = [ dot(Nold.x,Nnew.x)  dot(Nold.x,Nnew.y)  dot(Nold.x,Nnew.z);  
      dot(Nold.y,Nnew.x)  dot(Nold.y,Nnew.y)  dot(Nold.y,Nnew.z);
      dot(Nold.z,Nnew.x)  dot(Nold.z,Nnew.y)  dot(Nold.z,Nnew.z)];

 T = R*TT*R.';