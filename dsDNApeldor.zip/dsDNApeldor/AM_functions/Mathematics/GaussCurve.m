function y=GaussCurve(r,r0,sigma)
%Normalized Gaussian Distribution
y=exp(-(r-r0).^2./(2.*sigma.^2))./sqrt(2.*pi.*sigma.^2);