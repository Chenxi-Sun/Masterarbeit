function [x,Fx] = FourierTransformInv(Fy,y)

N = floor(length(y)./2);
% N must be an odd number

Y = y(end) - y(1);   x = (2.*pi./Y).*(-N:1:N).';

P = exp(1i.*x.*y(1));

Fx = P.*fftshift(ifft(Fy)).*(Y./(2.*N)).*(1./sqrt(2.*pi));

plot(x,real(Fx),x,imag(Fx));