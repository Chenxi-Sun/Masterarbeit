function y=KroneckerDelta(m,n)
%Kroneker delta is the function of two variables, 
%which is 1 if they are equal and 0 otherwise.
if m==n
    y=1; 
else
    y=0; 
end