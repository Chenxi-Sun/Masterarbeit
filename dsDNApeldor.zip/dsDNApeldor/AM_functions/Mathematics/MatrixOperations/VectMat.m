function y=VectMat(x,X,n)
% This fuction calculates the product of a vector x (column) with a matrix X
% according to the rule y_ij=x_iA_ij
% n is number of dimension along which the products are calculated. The
% length of nth dimension is equal to the length of x
if n>1 
    M=ones(1,n); M(end)=length(x);xx=reshape(x,M);
else
    xx=x;
end
P=size(X); P(n)=1;
xxx=repmat(xx, P);

y=xxx.*X;