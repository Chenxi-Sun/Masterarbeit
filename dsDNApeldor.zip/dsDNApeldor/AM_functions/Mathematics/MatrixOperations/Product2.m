function [X,Y,FxFy]=Product2(x,y,fx,fy)
xx=x(:);yy=y(:);
Fx=fx(:);Fy=fy(:)';
[X,Y]=ndgrid(xx,yy);
FxFy=kron(Fx,Fy);
%mesh(X,Y,FxFy);