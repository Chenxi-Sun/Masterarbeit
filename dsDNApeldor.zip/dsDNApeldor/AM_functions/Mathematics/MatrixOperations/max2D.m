function [m,n]=max2D(A)
%This function search for the maximum in a 2D matrix
%[m,n] give the position of the maximum
% m is the row mumber
% n is the column number
[~,m]=max(max(A,[],2),[],1);
[~,n]=max(A(m,:));

