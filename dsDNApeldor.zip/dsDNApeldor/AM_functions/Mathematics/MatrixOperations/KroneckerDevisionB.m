function B=KroneckerDevisionB(C,A)
%B is the matrix that AxB=C
sizeC=size(C); sizeA=size(A); sizeB=sizeC./sizeA;

[a,n]=max(abs(A),[],2);
[amax,m]=max(a);

Amax=A(m,n(m));

M=(m-1).*sizeB(1)+(1:1:sizeB(1));
N=(n(m)-1).*sizeB(2)+(1:1:sizeB(2));

B=C(M,N)./Amax;