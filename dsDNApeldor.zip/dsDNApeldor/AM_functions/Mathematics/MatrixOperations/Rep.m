function y=Rep(A,N)
%This function replicate a matrix N times in the first new
%dimension
n=ndims(A);
if n==2 
    if size(A,n)==1
        n=n-1;
    end
end
M=ones(1,n); D=[M N];

y=repmat(A,D);