function [m,n,p,Amin]=min3D(A)

[Amin,p]=min(min(min(A)));

B=A(:,:,p);

[x,n]=min(min(B));

C=B(:,n);

[x,m]=min(C);




