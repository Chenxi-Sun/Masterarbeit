function A=KroneckerDevisionA(C,B)
%A is the matrix that AxB=C
sizeC=size(C); sizeB=size(B); sizeA=sizeC./sizeB;

[b,n]=max(abs(B),[],2);
[bmax,m]=max(b);

Bmax=B(m,n(m));

M=(0:1:sizeA(1)-1)'.*sizeB(1)+m;
N=(0:1:sizeA(2)-1)'.*sizeB(2)+n(m);

A=C(M,N)./Bmax;