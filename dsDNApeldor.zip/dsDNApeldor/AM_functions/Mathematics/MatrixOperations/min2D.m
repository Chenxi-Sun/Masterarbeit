function [m,n]=min2D(A)
%This function seach for the minimum in a 2D matrix
%[m,n] give the position of the minimum
% m is the row mumber
% n is the column number
[~,m]=min(min(A,[],2),[],1);
[~,n]=min(A(m,:));

