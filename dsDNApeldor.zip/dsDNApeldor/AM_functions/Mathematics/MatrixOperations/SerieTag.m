function N1=SerieTag(X)
% X is a 2D Matrix

N=size(X,1);  d=zeros(N,1);
N1=(1:1:N).'; N2=ones(N,1);
k=1; K=1;
while any(N2)>0
   
    for i1=1:size(X,1)
        d(i1,1)=sum((X(i1,:)-X(k,:)).^2);
    end
     
    
    q=d==0;
    N1(q)=K;   N2(q)=0;
    K=K+1;     k=find(N2, 1 );
    
     disp(K);
end