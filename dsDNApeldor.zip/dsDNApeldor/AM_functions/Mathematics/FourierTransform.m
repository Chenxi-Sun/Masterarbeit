function [y,Fy] = FourierTransform(Fx,x)
% length(x) must be an odd number
N = floor(length(x)./2);
% N must be an odd number     (It needs to be clarified)

X = x(end) - x(1);   y = (2.*pi./X).*(-N:1:N).';

P = exp(-1i.*y.*x(1));

Fy = P.*fftshift(fft(Fx)).*(X./(2.*N)).*(1./sqrt(2.*pi));

plot(y,real(Fy),y,imag(Fy));