function y=LorentzCurve(r,r0,gamma)
%Normalized Lorentz Distribution
y=(1/pi).*gamma./((r-r0).^2+gamma.^2);