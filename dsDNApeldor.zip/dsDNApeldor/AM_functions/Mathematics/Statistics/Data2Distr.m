function [y,x]=Data2Distr(Data,Edges,Opt)
% The program compute statistics of the data
% It calculates the number of data points within bins
% Bins edges are specified by the variable Edges
% If bins do not cover the whole range of data then data is reduced to the
% covered rigion
% If Edges are not specified then the program search them automatically
% The value of Opt the must be Opt=0
% x corresponds to the center of the bins
if Opt==0
    N=40;
    x0=min(Data); x00=max(Data); dx=(x00-x0)./N;
    EDGES=linspace(x0,x00,N+1).'; 
    f=histcounts(Data,EDGES).'; 
    
    x=linspace(x0+dx/2,x00-dx/2,N).';
    y=f./trapz(x,f);
else
    n=find(Edges(1)<Data & Data<Edges(end));
    data=Data(n);
    f=histcounts(data,Edges).';
    x=Edges(1:end-1)+diff(Edges)./2;
    y=f./trapz(x,f); 
end

     plot(x,y);