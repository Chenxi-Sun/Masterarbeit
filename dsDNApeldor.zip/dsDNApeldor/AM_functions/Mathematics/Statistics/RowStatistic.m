function [DistinctRow,N]=RowStatistic(X)
% X is a 2D Matrix
% The program checks whether the matrix X has equal rows
% DistinctRow is a matrix which contains rows from X but all of them are
% different. Distinct row is obtained by elimination some rows from X if
% they are repeated. 
% vector N shows how mavy times each rows is repeated in X.
N=[];
DistinctRow=[];
while size(X,1)>=1
    M=[];
    for i1=1:size(X,1)
        a=sum((X(i1,:)-X(1,:)).^2);
        if a==0
            M=[M; i1];
        end
    end
    NM=numel(M);
    N=[N;NM];
    DistinctRow=[DistinctRow; X(1,:)];
    X(M,:)=[];
end