function [t,S] = PELDORsignals(Data,Result)
Texp = Data.T; Sexp = Data.Sexp;

N = length(Texp); n0 = 6; n00 = 0; Nexp = (n0:1:N-n00);
t = Texp(Nexp); t = t - t(1); 
Sexp0 = Sexp(Nexp,:);

lambda = Result.LAMBDAS; z = Result.z; r = Result.Conformers.Distance;


D=0.326983340102601; 
nL = size(lambda); nT = size(t); nR = size(r);
[T,Z] = ndgrid(t,z);

a = (0.8:0.01:1.1).'; Na = length(a); dScaledS = zeros(Na,1);

S = zeros(nT(1),nL(1));

for k1 = 1:nL(1)
    ds = 0;
    for k2 = 1:nR(1)
        L = repmat(lambda(k1,:,k2),[nT(1) 1]);
        ds = ds + trapz(z,L.*(cos(D.*T.*(3.*Z.^2-1)./r(k2).^3)-1),2);
    end
    ds = ds./nR(1);
    
    for k0 = 1:Na
    dScaledS(k0) = sum((1+a(k0).*ds - Sexp0(:,k1)).^2,1);
    end
    [~,minK] = min(dScaledS);
    S(:,k1) = 1 + a(minK).*ds;
end


PELDORplot(t, Sexp0, t, S);